package RibbonLoadBalancer.RibbonLoadBalancer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RibbonLoadBalancerApplicationTests {

	@Test
	void contextLoads() {
	}

}
