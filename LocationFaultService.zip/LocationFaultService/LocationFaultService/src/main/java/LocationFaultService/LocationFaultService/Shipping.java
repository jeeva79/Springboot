package LocationFaultService.LocationFaultService;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/shopping")
public class Shipping {

	/*This contains the routing and ping logic.
	 * This has to be Autowired.
	 * Any Hystrix application will have customized routing logic.*/
	@Autowired
	ProductService  locService;
	
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public ArrayList<product> getStoreInfo() {
		return locService.getStoreInfo();
	}
}
