package BackendDevelopers.FirstSpringBoot.model;

import jakarta.persistence.*;


//linking POJO class to the table in the DB...


@Entity
@Table(name="product")


public class product {

	@Id   //in the DB this column is a primary Key..
	
	//for generating primary key values automatically..
	
	@GeneratedValue(strategy = GenerationType.AUTO)     
    private int productId; 
	
	//link productNmae variable with productName column in the DB...
	
	@Column(name = "productName")
    private String productName;

    // Default constructor
    public product() {
        super();
        System.out.println("New product created...");
    }

    // Parameterized constructor
    public product(int productId, String productName) {
        super();
        this.productId = productId;
        this.productName = productName;
        System.out.println("New product with ID and Name created...");
    }

    // Getter and Setter
    public int getproductId() {
        return productId;
    }

    public void setproductId(int productId) {
        this.productId = productId;
    }

    public String getproductName() {
        return productName;
    }

    public void setproductName(String productName) {
        this.productName = productName;
    }

    @Override
    public String toString() {
        return "product [productId=" + productId + ", productName=" + productName + "] " + hashCode();
    }
}