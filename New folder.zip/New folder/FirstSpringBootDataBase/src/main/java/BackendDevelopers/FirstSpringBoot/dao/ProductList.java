package BackendDevelopers.FirstSpringBoot.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import BackendDevelopers.FirstSpringBoot.model.product;


@Repository
public interface ProductList extends CrudRepository<product , Integer>{

	/*Crud-repository<product,Integer>
	 * product is the data that will inserted into the data or retrieved from the database
	 * Integer is the data-type of the primary key.......*/
	
	
	
	}
	

