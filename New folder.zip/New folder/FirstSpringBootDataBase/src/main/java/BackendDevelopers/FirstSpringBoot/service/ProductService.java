package BackendDevelopers.FirstSpringBoot.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.dao.ProductList;
import BackendDevelopers.FirstSpringBoot.model.product;


 
//any class marked with @service control concurrent or parallel access to the DAO layer,
//there by preventing data loss or data ambiguity or data corruption..

@Service       // automatically create a bean for product-service.

public class ProductService {
 
	@Autowired
	
	ProductList plist;
	
	
	
	public  ArrayList<product> getProductList(){
		System.out.println("Getting products list...");
		//when you call findall() method in the repository,
		//it executes a SQL SELECT * from product statement on the database..
		return (ArrayList<product>)plist.findAll();
}
	
	
	public String addProduct(product p) {
		System.out.println("In service adding product...");
		product t = plist.save(p);  // save means insert //converts this SQL statement..
		return "<b>Added or insert the product</b> " + t;
}
	
	
	
	public String deleteProduct(int productId) {
		System.out.println("In service delete product....");
		//ex: if productId is 3,
		//when deleteById() is called, It convert this into 
		//SQL DELETE from product where productId = 3
 		plist.deleteById(productId);
		return "<b>Deleted product with ID</b>" + productId;	 
}
	
	
	
	public String searchById(int productId) {
		System.out.println("In service search product...");
		//if product is 4, this is converted to SQL 
		//SELECT *  from product where productId = 4
       Optional<product> opt = plist.findById(productId);
        return "<b>Located productId </b>" + opt.get().toString(); 
	}
	
	
	
	
	public String updateProduct(int productId , String newProductName) {
		System.out.println("In service update product...");
		product d = new product(productId, newProductName);
		//when save() method is called, if any product with given productId is existing,
		//it updates productName with newProductName. otherwise it inserts a new record.
		return "<b>Update product with</b>" + plist.save(d).toString();
	}
}


	

