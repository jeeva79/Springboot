package ipl.team.dao;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ipl.team.model.team;



@Repository
public interface TeamList extends CrudRepository<team , Integer>{

	/*Crud-repository<product,Integer>
	 * product is the data that will inserted into the data or retrieved from the database
	 * Integer is the data-type of the primary key.......*/
	
	
	
	}