package ipl.team.model;

import jakarta.persistence.*;

@Entity
@Table(name="Cricket")
public class team {


	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productId;
	
	@Column(name = "productName")
	private String productName;
	
	public team() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("New Teams Created....");
	}
	
	public team(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
		System.out.println("New Teams Created with ID and Name....");
	}


	public int getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}


	@Override
	public String toString() {
		return "team [productId=" + productId + ", productName=" + productName + "]" + "     -     " + hashCode();
	}
	
}
