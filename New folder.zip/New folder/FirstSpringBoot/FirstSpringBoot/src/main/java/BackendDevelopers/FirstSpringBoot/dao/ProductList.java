package BackendDevelopers.FirstSpringBoot.dao;

import java.util.HashMap;

import BackendDevelopers.FirstSpringBoot.model.product;

public class ProductList {

	public HashMap<Integer,product> ProductList= new HashMap<>();
	
	
	public ProductList() {
		
		    ProductList.put(1, new product(1, "Samsung JH78"));
	        ProductList.put(2, new product(2,"Samsung E34"));
	        ProductList.put(3, new product(3, "Samsung A43"));
	        ProductList.put(4, new product(4,"Samsung A55"));
	        System.out.println("product list created...");

	}
	
	public  HashMap<Integer, product> getProductList(){
		System.out.println("Retived product list and sent it... ");
		return ProductList;
	}
	
	public String addProduct(product p) {
		ProductList.put(p.getproductId(), p);
		System.err.println("Added a new Product");
		return "<b>Product added successfully" + " Use /list of products.... </b>";
		}
	
	
	
	public String deleteProduct(int productId) {
		  product p = ProductList.get(productId);
	        if (p != null) {
	        	ProductList.remove(productId);
	            return "<b>Product Deleted:</b> " + p;
	        }
	        else {
	            return "<b>Product Not Found</b>";
	        }
}
	
	
	
	
	public String searchById(int productId) {
		 product p = ProductList.get(productId);
	        if (p != null) {
	            return "<b>Product Found:</b> " + p;
	        } else {
	            return "<b>Product Not Found</b>";
	        }
}
	
	
	
	
	public String updateProduct(int productId , String newProductName) {
		product p = ProductList.get(productId); 
		 if (p != null) {
			 p.setproductName(newProductName);
			 ProductList.put(p.getproductId(), p);
	            return "<b>Product Updated Successfully:</b> " + productId;
	        }else
	       
	        return "<b>Product ID Not Found:</b> ";
	    }
	}
	

