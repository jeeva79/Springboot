package BackendDevelopers.FirstSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootApplication {

	//entry point for springboot application.....
	
	public static void main(String[] args) {
		
		//start the tomcat server and deploys the web on the tomcat server...
		
		SpringApplication.run(FirstSpringBootApplication.class, args);
		System.out.println("start the server.....");
	}

}
