package BackendDevelopers.FirstSpringBoot.model;

public class product {

    private int productId;          
    private String productName;

    // Default constructor
    public product() {
        super();
        System.out.println("New product created...");
    }

    // Parameterized constructor
    public product(int productId, String productName) {
        super();
        this.productId = productId;
        this.productName = productName;
        System.out.println("New product with ID and Name created...");
    }

    // Getter and Setter
    public int getproductId() {
        return productId;
    }

    public void setproductId(int productId) {
        this.productId = productId;
    }

    public String getproductName() {
        return productName;
    }

    public void setproductName(String productName) {
        this.productName = productName;
    }

    @Override
    public String toString() {
        return "product [productId=" + productId + ", productName=" + productName + "] " + hashCode();
    }
}