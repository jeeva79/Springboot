package BackendDevelopers.FirstSpringBoot.service;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.dao.ProductList;
import BackendDevelopers.FirstSpringBoot.model.product;


 
//any class marked with @service control concurrent or parallel access to the DAO layer, there by preventing data loss or data ambiguity or data corruption..

@Service  // automatically create a bean for productservice.

public class ProductService {
 
	//manually injecting the productList object into this service...
	
	ProductList plist = new ProductList();
	
	
	
	public  HashMap<Integer, product> getProductList(){
		System.out.println("getting products list...");
		return plist.getProductList();
}
	
	
	public String addProduct(product p) {
		System.out.println("In service adding product...");
		return plist.addProduct(p);
}
	
	
	
	public String deleteProduct(int productId) {
		System.out.println("In service delete product....");
		return plist.deleteProduct(productId);
		 
}
	
	
	
	public String searchById(int productId) {
		System.out.println("In service search product...");
		return plist.searchById(productId);
}
	
	
	
	
	public String updateProduct(int productId , String newProductName) {
		System.out.println("In service update product...");
		return plist.updateProduct(productId, newProductName);
	}
}


	

