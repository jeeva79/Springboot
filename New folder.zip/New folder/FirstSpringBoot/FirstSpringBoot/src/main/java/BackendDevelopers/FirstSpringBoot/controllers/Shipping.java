package BackendDevelopers.FirstSpringBoot.controllers;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import BackendDevelopers.FirstSpringBoot.model.product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;


@RestController 
@RequestMapping("/shopping")
public class Shipping {

    private long visitorCount = 0;
   
    @Autowired
    ProductService service;

    public Shipping() {
    	System.err.println("shopping controller created...");
           }

    // Link this API with browser: http://localhost:9080/shopping/
    @RequestMapping(path = "/", method = RequestMethod.GET)
    public String home() {
        StringBuilder response = new StringBuilder();
        response.append("<html><body><h1><center>");
        response.append("Welcome to Online Shopping</center></h1><br>");
        response.append("<b>You are visitor # </b>").append(++visitorCount);
        response.append("<h3>Hi Jeeva!</h3>");
        response.append("</body></html>");
        return response.toString();
    }

    // Return product list
    @GetMapping("/list")
    public HashMap<Integer, product> getProductList() {
        return service.getProductList();
    }
    

    // Search product using RequestParam
    @GetMapping("/search")
    public String searchProduct(@RequestParam("pId") int productId) {
       return service.searchById(productId);
    }

    // Delete product using productId (path variable)
    @DeleteMapping(path = "/deleteId/{pId}")
    public String deleteProduct(@PathVariable("pId") int productId) {
        System.out.println("Got a DELETE request for product ID: " + productId);
        return service.deleteProduct(productId);
    }

    
    
    // add existing product name
    @PostMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String addProduct(@RequestBody product p) {
      return service.addProduct(p);
 }
    
    // Update existing product name
    @PutMapping(value = "/update/{pId}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String updateProduct(@RequestBody product p) {
      return service.updateProduct(p.getproductId(), p.getproductName());
 }
}
