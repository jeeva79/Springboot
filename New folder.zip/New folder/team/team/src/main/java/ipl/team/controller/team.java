package ipl.team.controller;

public class team {

	private String productId;
	private String productName;
	
	public team() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("New Teams Created....");
	}
	
	public team(String productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
		System.out.println("New Teams Created with ID and Name....");
	}


	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}


	@Override
	public String toString() {
		return "team [productId=" + productId + ", productName=" + productName + "]" + "     -     " + hashCode();
	}
	
}
