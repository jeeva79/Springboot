package ipl.team.controller;

import java.util.Collection;
import java.util.HashMap;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/ipl")
public class Cricket {

		public  HashMap<String, String> iplTeams = new HashMap<>();
		
		
	    public Cricket() {
	        iplTeams.put("CSK", "Chennai Super Kings");
	        iplTeams.put("MI", "Mumbai Indians");
	        iplTeams.put("RCB", "Royal Challengers Bengaluru");
	        iplTeams.put("KKR", "Kolkata Knight Riders");
	        iplTeams.put("RR", "Rajasthan Royals");
	        iplTeams.put("DC", "Delhi Capitals");
	        iplTeams.put("SH", "Sunrisers Hyderabad");
	        iplTeams.put("LSG", "Lucknow Super Giants");
	        iplTeams.put("PK", "Punjab Kings");
	       
	    }
	    
	    
	    
	    
	    
	    @GetMapping(path="/teams",produces=MediaType.APPLICATION_JSON_VALUE)
	    public Collection<String> getAllTeams() {
	        return iplTeams.values();
	    }
	    
	    
	    
	    
	    
	    
	    @GetMapping("/search")
	    public String searchTeam(@RequestParam("tid") String teamId) {
	    	 teamId =teamId.toUpperCase();
	        String teamName = iplTeams.get(teamId);
	        
	        if (teamName != null) {
	            return "<b>Team Found:</b> " + teamName;
	        } else {
	            return "<b>Team Not Found</b>";
	        }
	    }

	    
	    
	    
	    
	   
	    @DeleteMapping("/delete/{tid}")
	    public String deleteTeam(@PathVariable("tid") String teamId) {
	        System.out.println("Received delete request for team ID: " + teamId);
	        teamId =teamId.toUpperCase();

	        String teamName = iplTeams.remove(teamId);

	        if (teamName != null) {
	            return "<b>Team Deleted Successfully:</b> " + teamName;
	        } else {
	            return "<b>Team ID Not Found:</b> " + teamId;
	        }

	    }     
	    
	    
	    
	    
	    
	    
	    
//	    @PostMapping("/add")//consumes="application/form-data"
//	        public HashMap<String,String> addTeam(@RequestBody team T) {
//	    	System.out.println("Got a Post Request....");
//	    	iplTeams.put(T.getProductName(), T.getProductName());
//	        	return iplTeams;
	        	
	    @PostMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE)
	    public HashMap<String, String> addTeam(@RequestBody team T) {
	        System.out.println("Got a Post Request...");
	        iplTeams.put(T.getProductId().toUpperCase(), T.getProductName());
	        return iplTeams;
	        }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    @PatchMapping(value = "/update/{tid}", consumes = MediaType.APPLICATION_JSON_VALUE)
	    public String updateTeam(@PathVariable("tid") String teamId, @RequestBody team T) {
	        teamId = teamId.toUpperCase();
	        
	        System.out.println("Got a Patch Request...");
	        if (!iplTeams.containsKey(teamId)) {
	            return "<b>Team ID Not Found:</b> " + teamId;
	        }

	        iplTeams.put(teamId, T.getProductName());

	        return "<b>Team Updated Successfully:</b> " + T.getProductName();
	    }

	    
	    
	    
	    
	    @PutMapping(value = "/replace/{tid}", consumes = MediaType.APPLICATION_JSON_VALUE)
	    public String replaceTeam(@PathVariable("tid") String teamId, @RequestBody team T) {
	    	 System.out.println("Got a Put Request...");
	    	 if (iplTeams.isEmpty()) {
	    	        return "<b>No Teams Found</b>";
	    	    }
	    	 
	        teamId = teamId.toUpperCase();

	        iplTeams.put(teamId, T.getProductName());

	        return "<b>Team Replaced Successfully:</b> " + T.getProductName();
	    }
	        


	    }