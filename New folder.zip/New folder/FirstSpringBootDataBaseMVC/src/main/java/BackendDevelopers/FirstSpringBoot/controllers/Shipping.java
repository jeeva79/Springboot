package BackendDevelopers.FirstSpringBoot.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import BackendDevelopers.FirstSpringBoot.model.product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;



@RestController 
@RequestMapping("/shopping")
public class Shipping {

    private long visitorCount = 0;
   
    @Autowired
    ProductService service;

    //create an object for product-service class automatically. 
    //so, that becomes a bean. that bean is injected into the controller(shopping). 
    //This  is an example of dependency injection mechanism,
    //Auto-wiring is a type of dependency injection mechanism...
    
    
    public Shipping() {
    	System.err.println("shopping controller created...");
           }

    // Link this API with browser: http://localhost:9080/shopping/
    @RequestMapping(path = "/", method = RequestMethod.GET)
    public ModelAndView home() {
       ModelAndView mv = new ModelAndView();
       mv.setViewName("home");
       mv.addObject("visCount", visitorCount++);
       return mv;
    }

    // Return product list
    @GetMapping("/list")
    public ModelAndView getProductList() {
    	ModelAndView mv = new ModelAndView();
    	
    	//html file will be display..
    	
    	mv.setViewName("listProduct");
    	
    	//attaching the model(data) with the view..
    	
        mv.addObject("products",service.getProductList());
        return mv;  
    }
    

    
    // Search product using RequestParam
//    @GetMapping("/search")
//    public String searchProduct(@RequestParam("pId") int productId) {
//       return service.searchById(productId);
//    }

    @GetMapping("/searchProduct")
    public ModelAndView searchProduct(@RequestParam(value = "productId", required = false) Integer productId) {
        ModelAndView mv = new ModelAndView("searchResult");

        if (productId == null) {
            mv.addObject("message", "Please enter a Product ID.");
            return mv;
        }

        String result = service.searchById(productId);
        mv.addObject("message", result);
        return mv;
    }


    
    @GetMapping("/search")
    public ModelAndView showSearchForm() {
        // Returns the HTML page with the search form
        return new ModelAndView("searchProduct");
    }


    
    // Delete product using productId (path variable)
//    @DeleteMapping(path = "/deleteId/{pId}")
//    public String deleteProduct(@PathVariable("pId") int productId) {
//        System.out.println("Got a DELETE request for product ID: " + productId);
//        return service.deleteProduct(productId);
//    }
    
    
    
    
    @GetMapping("/delete")
	public ModelAndView delete() {
		 ModelAndView mv = new ModelAndView();
		 mv.setViewName("deleteProduct"); 
		 mv.addObject("products", service.getProductList()); // refresh the list
		 mv.addObject("message", "The Product was deleted..."); // show success message
		 return mv;
	}
	@PostMapping("/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("productId") int productId) {
	    String message = service.deleteProduct(productId);
	    ModelAndView mv = new ModelAndView("deletedProduct");
	    mv.addObject("message", "Product ID " + productId + " deleted successfully.");
	    mv.addObject("product", service.getProductList());
	    return mv;
	} 
    
    
    

    
//    @GetMapping("/delete")
//    public ModelAndView deleteProduct(@RequestParam("productId") int productId) {
//        product deletedProduct = service.deleteProduct(productId);
//
//        ModelAndView mv = new ModelAndView();
//        mv.setViewName("deletedProduct");
//        mv.addObject("product", deletedProduct);
//
//        return mv;
//    }
//
//    @PostMapping("/deleteProduct")
//    public ModelAndView deleteProduct(@ModelAttribute product product) {
//        ModelAndView mv = new ModelAndView();
//
//        // Call the service layer to delete the product
//        product deleted = service.deleteProduct(product.getproductId());
//
//        // Set view and model
//        mv.setViewName("deletedProduct");
//        mv.addObject("product", deleted);
//
//        return mv;
//    }
//

    
    
    // add existing product name
    @PostMapping(value = "/addProduct" )//,consumes = MediaType.APPLICATION_JSON_VALUE)
    public ModelAndView addProduct(@ModelAttribute product p) {
    	ModelAndView mv = new ModelAndView();
      product t = service.addProduct(p);
      mv.setViewName("addedProduct");
      mv.addObject("product", t);
      return mv;
 }
    
	

    
//    @PostMapping("/addProduct")
//    public ModelAndView addProduct(@ModelAttribute product p) {
//        product saved = service.addProduct(p);
//        return new ModelAndView("addedProduct", "product", saved);
//    }

    
    @GetMapping("/add")
	public ModelAndView addP() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addProduct");
		mv.addObject("Today",new java.util.Date().toString());
		visitorCount++;
		mv.addObject("vCount", visitorCount);
		return mv;
	}
    
    
//    // Update existing product name
//    @PutMapping(value = "/update/{pId}", consumes = MediaType.APPLICATION_JSON_VALUE)
//    public String updateProduct(@RequestBody product p) {
//      return service.updateProduct(p.getproductId(), p.getproductName());
// }

	@GetMapping("/update")
	public ModelAndView showUpdateForm() {
	    ModelAndView mv = new ModelAndView("updateProduct");
	    mv.addObject("products", service.getProductList());
	    mv.addObject("Today", new java.util.Date().toString());
	    mv.addObject("message", "Update an existing product");
	    return mv;
	}


	@PostMapping("/updateProduct")
	public ModelAndView updateProduct(@RequestParam("productId") int productId,
	                                  @RequestParam("productName") String productName) {
	    String updated = service.updateProduct(productId, productName);

	    ModelAndView mv = new ModelAndView("updatedProduct");
	    mv.addObject("product", service.getProductList());
	    mv.addObject("message", "Product updated successfully!");
	    return mv;
	}


}
