package Backend.ipl.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Backend.ipl.dao.TeamList;
import Backend.ipl.model.team;



@Service
public class CricketTeam {

    @Autowired
    private TeamList cteam;  

    public ArrayList<team> getProductList() {
        System.out.println("Getting products list...");
        return (ArrayList<team>) cteam.findAll();
    }

    public String addProduct(team t) {
        System.out.println("In service adding product...");
        team p = cteam.save(t);
        return "<b>Added or insert the product</b> " + p;
    }

    public String deleteProduct(int productId) {
        System.out.println("In service delete product....");
        cteam.deleteById(productId);
        return "<b>Deleted product with ID</b> " + productId;
    }

    public String searchById(int productId) {
        System.out.println("In service search product...");
        Optional<team> opt = cteam.findById(productId);
        if (opt.isPresent()) {
            return "<b>Located productId </b>" + opt.get().toString();
        } else {
            return "<b>No product found with ID</b> " + productId;
        }
    }

    public String updateProduct(int productId, String newProductName) {
        System.out.println("In service update product...");
        team d = new team(productId, newProductName);
        return "<b>Updated team:</b> " + cteam.save(d).toString();
    }


}