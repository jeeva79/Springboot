package com.complier.login;



import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class next
 */
@WebServlet("/next")
public class App extends HttpServlet {
	private static final long serialVersionUID = 1L;
       public int visitorCount = 0;
       public int score1 = 0;
       public int score2 = 0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public App() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        response.getWriter().println("<h1>Cricket Scores</h1>");
        response.getWriter().println("<p>Visitors: " + visitorCount + "</p>");
        response.getWriter().println("<p>Team 1 Score: " + score1 + "</p>");
        response.getWriter().println("<p>Team 2 Score: " + score2 + "</p>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}


