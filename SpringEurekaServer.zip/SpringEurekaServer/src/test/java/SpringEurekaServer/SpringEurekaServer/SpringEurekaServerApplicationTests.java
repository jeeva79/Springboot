package SpringEurekaServer.SpringEurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
